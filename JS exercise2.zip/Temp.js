var $ = function(id) {
    return document.getElementById(id);
};

To convert Fahrenheit to Celsius, first subtract 32 from the Fahrenheit
temperature. Then, multiply that result by 5/9.
